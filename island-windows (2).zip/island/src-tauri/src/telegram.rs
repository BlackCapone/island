//! Telegram: вход под своим аккаунтом (MTProto, крейт grammers), чтобы видеть личные
//! сообщения и группы. Бот для этого не подходит — он не видит ваши чаты.
//! api_id / api_hash берутся на https://my.telegram.org (раздел API development tools).

use grammers_client::{
    session::Session,
    types::{Chat, LoginToken, PasswordToken},
    Client, Config, InitParams, SignInError, Update,
};
use grammers_mtsender::FixedReconnect;
use serde::{Deserialize, Serialize};
use serde_json::json;
use base64::Engine;
use std::{
    collections::HashMap,
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
    time::Duration,
};
use tauri::{AppHandle, Emitter, Manager, State};

use crate::Shared;

/// true, когда собственный клиент работает (чтобы не дублировать уведомления Telegram Desktop).
pub static ACTIVE: AtomicBool = AtomicBool::new(false);

#[derive(Default)]
pub struct Tg {
    client: Option<Client>,
    login: Option<LoginToken>,
    pw: Option<PasswordToken>,
}

#[derive(Serialize, Deserialize)]
struct Cfg {
    api_id: i32,
    api_hash: String,
    #[serde(default)]
    proxy: Option<String>,
}

fn dir(app: &AppHandle) -> PathBuf {
    let d = app.path().app_config_dir().unwrap_or_default();
    let _ = std::fs::create_dir_all(&d);
    d
}

/// После обрыва связи пробуем переподключаться сами (по умолчанию библиотека сдаётся).
static RECONNECT: FixedReconnect = FixedReconnect { attempts: usize::MAX, delay: Duration::from_secs(3) };

const NET_HINT: &str = "Нет ответа от Telegram за 25 с. Если VPN работает как прокси (а не для всей системы), укажите SOCKS5-прокси в настройках";

async fn with_timeout<T>(f: impl std::future::Future<Output = Result<T, String>>) -> Result<T, String> {
    tokio::time::timeout(Duration::from_secs(25), f).await.map_err(|_| NET_HINT.to_string())?
}

async fn connect(d: &Path, api_id: i32, api_hash: String, proxy: Option<String>) -> Result<Client, String> {
    let session = Session::load_file_or_create(d.join("telegram.session")).map_err(|e| e.to_string())?;
    let params = InitParams {
        proxy_url: proxy.map(|p| p.trim().to_string()).filter(|p| !p.is_empty()),
        reconnection_policy: &RECONNECT,
        ..Default::default()
    };
    with_timeout(async {
        Client::connect(Config { session, api_id, api_hash, params })
            .await
            .map_err(|e| format!("Не удалось подключиться: {e}"))
    })
    .await
}

/// Аватарка собеседника (маленький JPEG → data URL). None, если фото нет или не скачалось.
async fn avatar(client: &Client, who: &Chat) -> Option<String> {
    let d = who.photo_downloadable(false)?;
    let mut it = client.iter_download(&d);
    let mut buf: Vec<u8> = Vec::new();
    while let Some(chunk) = it.next().await.ok()? {
        buf.extend(chunk);
        if buf.len() > 300_000 {
            return None;
        }
    }
    if buf.is_empty() {
        return None;
    }
    Some(format!("data:image/jpeg;base64,{}", base64::engine::general_purpose::STANDARD.encode(buf)))
}

/// Слушает новые входящие сообщения и отправляет их на остров.
fn run(app: AppHandle, client: Client) {
    ACTIVE.store(true, Ordering::SeqCst);
    tauri::async_runtime::spawn(async move {
        let mut avatars: HashMap<i64, Option<String>> = HashMap::new();
        loop {
            match client.next_update().await {
                Ok(Update::NewMessage(m)) if !m.outgoing() => {
                    let chat = m.chat();
                    if matches!(chat, Chat::Channel(_)) {
                        continue; // каналы не показываем
                    }
                    // у некоторых отправителей имя пустое — подставляем название чата, затем «Telegram»
                    let nonempty = |s: &str| (!s.trim().is_empty()).then(|| s.trim().to_string());
                    let sender = m
                        .sender()
                        .and_then(|s| nonempty(s.name()))
                        .or_else(|| nonempty(chat.name()))
                        .unwrap_or_else(|| "Telegram".to_string());
                    let name = if matches!(chat, Chat::Group(_)) && nonempty(chat.name()).is_some() {
                        format!("{sender} · {}", chat.name())
                    } else {
                        sender
                    };
                    let mut text = m.text().to_string();
                    if text.trim().is_empty() {
                        text = "Вложение".into();
                    }
                    let who = m.sender().unwrap_or_else(|| chat.clone());
                    let av = match avatars.get(&who.id()) {
                        Some(a) => a.clone(),
                        None => {
                            let a = tokio::time::timeout(Duration::from_secs(3), avatar(&client, &who))
                                .await
                                .ok()
                                .flatten();
                            avatars.insert(who.id(), a.clone());
                            a
                        }
                    };
                    let _ = app.emit("tg", json!({ "name": name, "text": text, "avatar": av }));
                }
                Ok(_) => {}
                Err(e) => {
                    eprintln!("island tg: {e}");
                    tokio::time::sleep(Duration::from_secs(5)).await;
                }
            }
        }
    });
}

fn finish(app: &AppHandle, client: &Client) {
    let _ = client.session().save_to_file(dir(app).join("telegram.session"));
    run(app.clone(), client.clone());
}

/// Автоподключение при запуске, если уже входили раньше. Сеть может появиться не сразу
/// (VPN, автозапуск вместе с Windows), поэтому повторяем попытки.
pub fn autostart(app: AppHandle) {
    tauri::async_runtime::spawn(async move {
        let d = dir(&app);
        let Ok(txt) = std::fs::read_to_string(d.join("telegram.json")) else { return };
        let Ok(cfg) = serde_json::from_str::<Cfg>(&txt) else { return };
        loop {
            if let Ok(client) = connect(&d, cfg.api_id, cfg.api_hash.clone(), cfg.proxy.clone()).await {
                if matches!(with_timeout(async { client.is_authorized().await.map_err(|e| e.to_string()) }).await, Ok(true)) {
                    let state = app.state::<Shared>();
                    state.tg.lock().await.client = Some(client.clone());
                    run(app.clone(), client);
                }
                return;
            }
            tokio::time::sleep(Duration::from_secs(15)).await;
        }
    });
}

#[tauri::command]
pub fn tg_config(app: AppHandle) -> Option<serde_json::Value> {
    let txt = std::fs::read_to_string(dir(&app).join("telegram.json")).ok()?;
    serde_json::from_str(&txt).ok()
}

/// Возвращает "ok" (уже вошли) или "phone" (нужен вход по номеру).
#[tauri::command]
pub async fn tg_connect(
    app: AppHandle,
    state: State<'_, Shared>,
    api_id: i32,
    api_hash: String,
    proxy: Option<String>,
) -> Result<String, String> {
    let d = dir(&app);
    let api_hash = api_hash.trim().to_string();
    let cfg = serde_json::to_string(&Cfg { api_id, api_hash: api_hash.clone(), proxy: proxy.clone() })
        .map_err(|e| e.to_string())?;
    std::fs::write(d.join("telegram.json"), cfg).map_err(|e| e.to_string())?;
    let client = connect(&d, api_id, api_hash, proxy).await?;
    let authorized =
        with_timeout(async { client.is_authorized().await.map_err(|e| format!("Telegram отклонил запрос: {e}")) }).await?;
    state.tg.lock().await.client = Some(client.clone());
    if authorized {
        finish(&app, &client);
        Ok("ok".into())
    } else {
        Ok("phone".into())
    }
}

#[tauri::command]
pub async fn tg_phone(state: State<'_, Shared>, phone: String) -> Result<(), String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let token = with_timeout(async { c.request_login_code(phone.trim()).await.map_err(|e| format!("Не удалось запросить код: {e}")) }).await?;
    g.login = Some(token);
    Ok(())
}

/// Возвращает "ok" или "password" (включена двухфакторная защита).
#[tauri::command]
pub async fn tg_code(app: AppHandle, state: State<'_, Shared>, code: String) -> Result<String, String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let token = g.login.take().ok_or("сначала запросите код")?;
    match c.sign_in(&token, code.trim()).await {
        Ok(_) => {
            finish(&app, &c);
            Ok("ok".into())
        }
        Err(SignInError::PasswordRequired(p)) => {
            g.pw = Some(p);
            Ok("password".into())
        }
        Err(e) => {
            g.login = Some(token);
            Err(e.to_string())
        }
    }
}

#[tauri::command]
pub async fn tg_password(app: AppHandle, state: State<'_, Shared>, password: String) -> Result<(), String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let p = g.pw.take().ok_or("пароль не запрашивался")?;
    c.check_password(p, password.trim()).await.map_err(|e| e.to_string())?;
    finish(&app, &c);
    Ok(())
}
