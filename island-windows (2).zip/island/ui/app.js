'use strict';
const T = window.__TAURI__, $ = id => document.getElementById(id), isl = $('isl');
const sleep = ms => new Promise(r => setTimeout(r, ms));
const invoke = (c, a) => T.core.invoke(c, a), listen = (e, f) => T.event.listen(e, x => f(x.payload));
const F = d => `<path fill="currentColor" stroke="none" d="${d}"/>`;
const IC = {
  tg: F('M21.5 4.5 2.8 11.7c-.8.3-.8 1.3 0 1.6l4.6 1.5 1.8 5.5c.2.6 1 .8 1.4.3l2.6-2.6 4.6 3.4c.6.4 1.3.1 1.5-.6l3.1-15c.2-.8-.5-1.5-1.3-1.3zM9.5 14.2l8.2-5.1-6.3 6.1-.3 3.1z'),
  cc: (() => { let s = ''; for (let k = 0; k < 12; k++) { const a = k * Math.PI / 6, r = k % 2 ? 7.5 : 10; s += `<path d="M${(12 + 2.2 * Math.cos(a)).toFixed(2)} ${(12 + 2.2 * Math.sin(a)).toFixed(2)}L${(12 + r * Math.cos(a)).toFixed(2)} ${(12 + r * Math.sin(a)).toFixed(2)}"/>`; } return s; })(), play: F('M8 5v14l11-7z'), pause: F('M7 5h3.5v14H7zM13.5 5H17v14h-3.5z'),
  prev: F('M6 6h2v12H6zM9.5 12 18 6v12z'), next: F('M16 6h2v12h-2zM6 18V6l8.5 6z'), stop: F('M6 6h12v12H6z'), bolt: F('M13 2 4 14h6l-1 8 9-12h-6z'),
  rec: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4" fill="currentColor"/>',
  shot: '<path d="M4 8V6a2 2 0 0 1 2-2h2M16 4h2a2 2 0 0 1 2 2v2M20 16v2a2 2 0 0 1-2 2h-2M8 20H6a2 2 0 0 1-2-2v-2"/><rect x="8" y="9" width="8" height="6" rx="1.5"/>',
  mic: '<rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>', spk: '<path d="M4 9v6h4l5 4V5L8 9z"/><path d="M16.5 8.5a5 5 0 0 1 0 7"/>',
  screen: '<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>', window: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 9h18"/>', area: '<rect x="4" y="5" width="16" height="14" rx="2" stroke-dasharray="3 3"/>',
  hp: '<path d="M4 15v-3a8 8 0 0 1 16 0v3"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>', bat: '<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 11v2M7 10.5v3"/>',
  check: '<path d="m5 12 5 5 9-10" stroke-width="3.5"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>', folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  copy: '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h8"/>'
};
const svg = (n, s = 18) => `<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${IC[n]}</svg>`;
document.querySelectorAll('[data-ic]').forEach(e => e.innerHTML = svg(e.dataset.ic, e.dataset.sz || 18));

// ── таблицы состояний ──
const M = {
  tg: { c: '#2aabee', i: 'tg' }, cc: { c: '#d97757', i: 'cc', n: 'Claude Code' }, win: { c: '#5865f2', i: 'W' },
  hp: { c: '#3a3a40', i: 'hp' }, chg: { c: '#1f8f45', i: 'bolt', n: 'Зарядка', rc: '#30d158' },
  low: { c: '#ff453a', i: 'bat', n: 'Низкий заряд', t: 'Подключите зарядку', rc: '#ff453a' }
};
const SZ = {
  clock: [150, 36], music: [350, 64], tg: [350, 60], cc: [350, 60], win: [350, 60], hp: [350, 60], chg: [350, 60], low: [350, 60], file: [350, 60],
  ask: [380, 236], perm: [380, 190], work: [210, 38], hover: [290, 92], orec: [390, 222], oshot: [390, 152], count: [110, 56],
  rec: [390, 46], saved: [360, 64], hidden: [0, 0]
};
const VIEW = {
  clock: 'v-clock', music: 'v-music', tg: 'v-msg', cc: 'v-msg', win: 'v-msg', hp: 'v-msg', chg: 'v-msg', low: 'v-msg', ask: 'v-ask', perm: 'v-perm',
  work: 'v-work', hover: 'v-hover', orec: 'v-opts', oshot: 'v-opts', count: 'v-count', rec: 'v-rec', saved: 'v-saved', file: 'v-file', hidden: ''
};
const PRI = { perm: 3, ask: 3, tg: 2, win: 2, cc: 2, hp: 2, chg: 2, low: 2, file: 1 }, STICKY = { perm: 1, ask: 1 };
const BUSY = ['rec', 'count', 'hidden', 'orec', 'oshot'], BASE = ['clock', 'music', 'work'];

let cur = 'clock', backTo = 'clock', isHover = false, media = null, musicOn = false, lastPlay = 0;
let working = false, wstart = 0, Q = [], curN = null, nt, bt, rt, ct, secs = 0, paused = false;
let folderKind = 'video', mode = 'screen', askS = null, dl = null;
const dlSeen = new Set();
const fmt = n => String(Math.floor(n / 60)).padStart(2, '0') + ':' + String(n % 60).padStart(2, '0');
const fmtSize = b => b > 1e9 ? (b / 1e9).toFixed(2) + ' ГБ' : (b / 1e6).toFixed(1) + ' МБ';
const base = () => working ? 'work' : musicOn ? 'music' : 'clock';

// ── отрисовка ──
function setMsg(s, d) {
  const m = { ...M[s], ...(d || {}) }, b = $('m-b');
  if (m.img) { b.style.background = `center / cover url(${m.img})`; b.innerHTML = ''; }
  else { b.style.background = m.c; b.innerHTML = IC[m.i] ? svg(m.i) : m.i; }
  $('m-n').textContent = (m.n || '') + (m.cnt > 1 ? ` (${m.cnt})` : ''); $('m-t').textContent = m.t || '';
  $('m-r').innerHTML = m.r ? `<span class="bat" style="color:${m.rc || '#fff'}">${m.r}</span>` : (curN && Q.length ? `<span class="qb">+${Q.length}</span>` : '');
}
function renderQ() {
  const q = askS.qs[askS.i];
  $('ask-h').textContent = q.header || 'Claude Code спрашивает';
  $('ask-q').textContent = q.question;
  const o = $('ask-o'); o.innerHTML = '';
  (q.options || []).forEach(op => {
    const b = document.createElement('button'); b.className = 'opt'; b.title = op.description || '';
    const sp = document.createElement('span'); sp.textContent = op.label; b.append(sp);
    if (op.description && op.description.length <= 22) { const sm = document.createElement('small'); sm.textContent = op.description; b.append(sm); }
    b.onclick = () => pick(q.question, op.label); o.append(b);
  });
}
const askHeight = () => {
  const q = askS.qs[askS.i];
  return 16 + 28 + 10 + 20 * Math.min(3, Math.max(1, Math.ceil(q.question.length / 38))) + 10 + (q.options || []).length * 41 + 6 + 24 + 12;
};
function report(w, h) { invoke('set_rect', { w, h }).catch(() => {}); }
function set(s) {
  cur = s; isl.dataset.s = s;
  if (s === 'ask' && curN && (!askS || askS.id !== curN.d.id)) askS = { id: curN.d.id, qs: curN.d.questions, i: 0, answers: {} };
  if (s === 'ask') renderQ();
  if (s === 'perm' && curN) {
    const d = curN.d, t = d.tool;
    $('perm-q').textContent = t === 'Bash' ? 'Выполнить команду?' : /^(Edit|Write|MultiEdit)$/.test(t) ? 'Изменить файл?' : `Использовать ${t}?`;
    $('perm-cmd').textContent = (t === 'Bash' ? '$ ' : '') + d.detail;
  }
  if (s === 'file' && dl) { $('f-n').textContent = 'Загрузка: ' + dl.name; $('fp').textContent = fmtSize(dl.size); }
  let [w, h] = SZ[s];
  if (s === 'ask') { h = askHeight(); isl.style.height = h + 'px'; } else isl.style.height = '';
  if (s === 'saved' && isl.classList.contains('one')) { w = 300; h = 44; }
  report(w, h);
  document.querySelectorAll('.v').forEach(v => v.classList.toggle('on', VIEW[s] === v.id));
  if (M[s]) setMsg(s, curN && curN.s === s ? curN.d : null);
  if (s === 'orec' || s === 'oshot') $('o-t').textContent = s === 'orec' ? 'Запись экрана' : 'Скриншот';
}

// ── очередь уведомлений с приоритетами ──
function back() { if (Q.length) return next(); set(base()); }
function next() {
  clearTimeout(nt); clearTimeout(bt);
  curN = Q.shift() || null;
  if (!curN) return back();
  set(curN.s);
  if (!STICKY[curN.s]) nt = setTimeout(next, curN.s === 'file' ? 4500 : 3500);
}
const srt = () => Q.sort((a, b) => PRI[b.s] - PRI[a.s]);
function notify(s, d = {}) {
  // Спам от одного отправителя склеиваем: остаётся последнее сообщение и счётчик (N)
  if (s === 'tg' || s === 'win') {
    const same = curN && curN.s === s && curN.d.n === d.n ? curN : Q.find(x => x.s === s && x.d.n === d.n);
    if (same) {
      same.d = { ...d, cnt: (same.d.cnt || 1) + 1 };
      if (same === curN) { setMsg(s, same.d); clearTimeout(nt); nt = setTimeout(next, 3500); }
      return;
    }
  }
  Q.push({ s, d }); srt();
  if (Q.length > 8) Q.length = 8; // длинный хвост очереди не копим
  if (!curN) { if (BUSY.includes(cur)) return; return next(); }
  if (!STICKY[curN.s] && PRI[Q[0].s] > PRI[curN.s]) { Q.push(curN); srt(); return next(); }
  if (M[curN.s]) setMsg(curN.s, curN.d);
}
function dropPending(id) {
  Q = Q.filter(x => !(x.d && x.d.id === id));
  if (curN && curN.d && curN.d.id === id) next();
}

// ── «сохранено» / ошибки ──
function saved(t, s, thumb, folder, ms = 4000, err = false) {
  const ic = $('sv-ic');
  if (thumb) { ic.className = 'thumb img'; ic.style.backgroundImage = `url(${thumb})`; ic.innerHTML = ''; }
  else { ic.className = err ? 'ok err' : 'ok'; ic.style.backgroundImage = ''; ic.innerHTML = svg(err ? 'x' : 'check', 13); }
  $('sv-t').textContent = t; $('sv-s').textContent = s || '';
  $('sv-f').style.display = folder ? '' : 'none';
  isl.classList.toggle('one', !s);
  set('saved'); clearTimeout(bt); bt = setTimeout(back, ms);
}
function answer(t) { clearTimeout(nt); curN = null; saved(t, '', 0, 0, 1500); }
const fail = (t, e) => saved(t, String(e).slice(0, 70), 0, 0, 5000, true);

// ── вопросы и разрешения Claude Code ──
function pick(question, label) {
  askS.answers[question] = label; askS.i++;
  if (askS.i < askS.qs.length) { renderQ(); const h = askHeight(); isl.style.height = h + 'px'; report(380, h); return; }
  invoke('claude_answer', { id: askS.id, value: JSON.stringify(askS.answers) });
  answer('Отправлено в Claude Code: ' + label);
}
$('ask-term').onclick = () => { invoke('claude_answer', { id: askS.id, value: 'terminal' }); answer('Ответьте в терминале'); };
const permBtns = document.querySelectorAll('[data-r]');
permBtns[0].onclick = () => { invoke('claude_answer', { id: curN.d.id, value: 'deny' }); answer('Отклонено'); };
permBtns[1].onclick = () => { invoke('claude_answer', { id: curN.d.id, value: 'allow' }); answer('Разрешено · Claude продолжает'); };

// ── музыка ──
const ctl = document.querySelectorAll('.ctl button');
ctl[0].onclick = () => invoke('media_cmd', { action: 'prev' });
$('pp').onclick = () => invoke('media_cmd', { action: 'toggle' });
ctl[2].onclick = () => invoke('media_cmd', { action: 'next' });
function refreshMusic() {
  const on = !!media && (media.playing || Date.now() - lastPlay < 30000);
  if (on !== musicOn) { musicOn = on; if (BASE.includes(cur) && !isHover) back(); }
}
setInterval(refreshMusic, 3000);

// ── скриншот ──
async function shoot(m) {
  set('hidden'); await sleep(450);
  try {
    const r = await invoke('capture_screenshot', { mode: m });
    folderKind = 'image'; saved('Скриншот сохранён', 'Скопирован · Изображения\\island', r.thumb, true);
  } catch (e) { e === 'cancel' ? back() : fail('Не удалось сделать снимок', e); }
}

// ── запись ──
function countdown(cb) {
  let n = 3; $('cn').textContent = n; set('count');
  ct = setInterval(() => { n--; if (n) $('cn').textContent = n; else { clearInterval(ct); cb(); } }, 800);
}
function enterRec() {
  clearInterval(rt); secs = 0; paused = false;
  $('rt').textContent = '00:00'; $('rt').style.color = ''; $('dot').classList.remove('p'); $('pz').innerHTML = svg('pause', 14);
  $('sys').classList.toggle('off', $('t-sys').classList.contains('off'));
  $('mic').classList.toggle('off', $('t-mic').classList.contains('off'));
  set('rec');
  rt = setInterval(() => { if (!paused) { secs++; $('rt').textContent = fmt(secs); } }, 1000);
}
$('go').onclick = async () => {
  set('hidden'); await sleep(350);
  try { await invoke('rec_prepare', { mode }); }
  catch (e) { return e === 'cancel' ? back() : fail('Запись не начата', e); }
  countdown(async () => {
    try {
      await invoke('rec_start', { sys: !$('t-sys').classList.contains('off'), mic: !$('t-mic').classList.contains('off') });
      enterRec();
    } catch (e) { fail('Запись не начата', e); }
  });
};
$('pz').onclick = async () => {
  const p = !paused;
  try { await invoke('rec_pause', { paused: p }); } catch (e) { return; }
  paused = p; $('dot').classList.toggle('p', p); $('rt').style.color = p ? '#9a9aa3' : ''; $('pz').innerHTML = svg(p ? 'play' : 'pause', 14);
};
['sys', 'mic'].forEach(k => $(k).onclick = e => {
  const off = e.currentTarget.classList.toggle('off'); invoke('rec_mute', { which: k, muted: off });
});
$('stop').onclick = async () => {
  clearInterval(rt); saved('Сохраняю запись…', '', 0, 0, 120000);
  try { await invoke('rec_stop'); folderKind = 'video'; saved('Запись сохранена', 'Видео\\island', 0, 1); }
  catch (e) { fail('Не удалось сохранить запись', e); }
};

// ── меню и кнопки ──
$('b-rec').onclick = () => set('orec'); $('b-shot').onclick = () => set('oshot'); $('o-x').onclick = back;
document.querySelectorAll('#seg button').forEach(b => b.onclick = () => {
  if (cur === 'oshot') return shoot(b.dataset.m);
  mode = b.dataset.m; document.querySelectorAll('#seg button').forEach(x => x.classList.toggle('sel', x === b));
});
['t-sys', 't-mic'].forEach(i => $(i).onclick = e => e.currentTarget.classList.toggle('off'));
$('sv-f').onclick = () => { invoke('open_folder', { kind: folderKind }); $('sv-s').textContent = 'Открываю папку…'; };

// Музыка: по наведению остров не раскрывается (там кнопки), раскрываем кликом по месту без кнопок
isl.addEventListener('click', e => {
  if (cur === 'music' && !e.target.closest('button')) { backTo = 'music'; set('hover'); }
});

// ── события от Rust ──
listen('hover', inside => {
  isHover = inside;
  if (inside) { if (cur === 'clock' || cur === 'work') { backTo = cur; set('hover'); } }
  else if (cur === 'hover') setTimeout(() => { if (cur === 'hover' && !isHover) back(); }, 150);
});
listen('media', m => {
  media = m;
  if (m) {
    if (m.playing) lastPlay = Date.now();
    $('tr-t').textContent = m.title || '—'; $('tr-a').textContent = m.artist || '';
    const a = $('art');
    if (m.art) { a.style.backgroundImage = `url(${m.art})`; a.classList.add('img'); } else { a.style.backgroundImage = ''; a.classList.remove('img'); }
    isl.classList.toggle('playing', m.playing); $('pp').innerHTML = svg(m.playing ? 'pause' : 'play', 24);
  }
  refreshMusic();
});
const oneLine = s => String(s || '').replace(/\s+/g, ' ').trim();
listen('tg', p => notify('tg', { n: oneLine(p.name) || 'Telegram', t: oneLine(p.text), img: p.avatar || null }));
listen('winnotif', p => {
  let h = 0; for (const ch of p.app) h = (h * 31 + ch.charCodeAt(0)) % 360;
  const title = oneLine(p.title), body = oneLine(p.body);
  // имя/заголовок всегда в первой строке, текст — во второй (длинное обрезается многоточием)
  notify('win', { c: `hsl(${h} 55% 42%)`, i: (p.app[0] || '!').toUpperCase(), img: p.icon || null, n: title || p.app || 'Windows', t: title ? (body || p.app) : body });
});
listen('battery', p => p.kind === 'charging'
  ? notify('chg', { t: 'Подключено к питанию', r: p.pct + '%' })
  : notify('low', { r: p.pct + '%' }));
listen('device', p => notify('hp', { n: p.name, t: 'Аудиоустройство подключено' }));
listen('download', p => {
  dl = p;
  if (cur === 'file') { $('f-n').textContent = 'Загрузка: ' + p.name; $('fp').textContent = fmtSize(p.size); }
  else if (!dlSeen.has(p.name)) { dlSeen.add(p.name); notify('file', p); }
});
listen('download_done', p => { dlSeen.delete(p.name); notify('win', { c: '#1f8f45', i: 'check', n: 'Загрузка завершена', t: p.name }); });
listen('claude', p => {
  if (p.kind === 'working') { working = true; wstart = Date.now(); if (BASE.includes(cur) && !isHover) back(); }
  else if (p.kind === 'done') { working = false; notify('cc', { t: p.text.replace(/\s+/g, ' ').trim().slice(0, 240) }); if (!curN && cur === 'work') back(); }
  else if (p.kind === 'ask') notify('ask', p);
  else if (p.kind === 'perm') notify('perm', p);
  else if (p.kind === 'cancel') dropPending(p.id);
});
setInterval(() => {
  if (working && Date.now() - wstart > 15 * 60e3) { working = false; if (cur === 'work') back(); }
  if (working) $('wt').textContent = Math.floor((Date.now() - wstart) / 60000) + ':' + String(Math.floor((Date.now() - wstart) / 1000) % 60).padStart(2, '0');
}, 1000);

function tick() { $('clk').textContent = new Date().toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }); }
tick(); setInterval(tick, 10000);
set('clock');
