//! Скриншоты и выбор области экрана. Координаты — физические пиксели экрана.

use serde::{Deserialize, Serialize};
use std::{io::Cursor, path::PathBuf, time::Duration};
use tauri::{
    AppHandle, Manager, PhysicalPosition, PhysicalSize, State, WebviewUrl, WebviewWindowBuilder,
};

use crate::Shared;

#[derive(Clone, Copy, Debug, Serialize, Deserialize)]
pub struct Region {
    pub x: i32,
    pub y: i32,
    pub w: i32,
    pub h: i32,
}

/// Папка Видео\island или Изображения\island (создаётся при необходимости).
pub fn save_dir(app: &AppHandle, kind: &str) -> Result<PathBuf, String> {
    let base = if kind == "video" { app.path().video_dir() } else { app.path().picture_dir() }
        .map_err(|e| e.to_string())?;
    let dir = base.join("island");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    Ok(dir)
}

pub fn stamp() -> String {
    chrono::Local::now().format("%Y-%m-%d %H-%M-%S").to_string()
}

/// Монитор, на котором сейчас курсор.
pub fn monitor_region() -> Region {
    use windows::Win32::{Foundation::POINT, Graphics::Gdi::*, UI::WindowsAndMessaging::GetCursorPos};
    unsafe {
        let mut p = POINT::default();
        let _ = GetCursorPos(&mut p);
        let hm = MonitorFromPoint(p, MONITOR_DEFAULTTONEAREST);
        let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
        let _ = GetMonitorInfoW(hm, &mut mi);
        let r = mi.rcMonitor;
        Region { x: r.left, y: r.top, w: r.right - r.left, h: r.bottom - r.top }
    }
}

/// Активное окно (остров не берёт фокус, поэтому это окно пользователя).
pub fn foreground_region() -> Option<Region> {
    use windows::Win32::{Foundation::RECT, Graphics::Dwm::*, UI::WindowsAndMessaging::*};
    unsafe {
        let h = GetForegroundWindow();
        if h.is_invalid() {
            return None;
        }
        let mut r = RECT::default();
        let dwm = DwmGetWindowAttribute(
            h,
            DWMWA_EXTENDED_FRAME_BOUNDS,
            &mut r as *mut RECT as *mut _,
            std::mem::size_of::<RECT>() as u32,
        );
        if dwm.is_err() {
            GetWindowRect(h, &mut r).ok()?;
        }
        let reg = Region { x: r.left, y: r.top, w: r.right - r.left, h: r.bottom - r.top };
        (reg.w > 0 && reg.h > 0).then_some(reg)
    }
}

/// Снимок области через GDI. Возвращает (ширина, высота, RGBA).
pub fn grab(r: Region) -> Result<(u32, u32, Vec<u8>), String> {
    use windows::Win32::Graphics::Gdi::*;
    if r.w <= 0 || r.h <= 0 {
        return Err("пустая область".into());
    }
    unsafe {
        let screen = GetDC(None);
        let mem = CreateCompatibleDC(screen);
        let bmp = CreateCompatibleBitmap(screen, r.w, r.h);
        let old = SelectObject(mem, bmp);
        let blit = BitBlt(mem, 0, 0, r.w, r.h, screen, r.x, r.y, SRCCOPY | CAPTUREBLT);

        let mut bi = BITMAPINFO::default();
        bi.bmiHeader = BITMAPINFOHEADER {
            biSize: std::mem::size_of::<BITMAPINFOHEADER>() as u32,
            biWidth: r.w,
            biHeight: -r.h, // сверху вниз
            biPlanes: 1,
            biBitCount: 32,
            biCompression: BI_RGB.0,
            ..Default::default()
        };
        let mut buf = vec![0u8; (r.w * r.h * 4) as usize];
        let lines = GetDIBits(
            mem,
            bmp,
            0,
            r.h as u32,
            Some(buf.as_mut_ptr() as *mut _),
            &mut bi,
            DIB_RGB_COLORS,
        );
        SelectObject(mem, old);
        let _ = DeleteObject(bmp);
        let _ = DeleteDC(mem);
        ReleaseDC(None, screen);
        if blit.is_err() || lines == 0 {
            return Err("не удалось сделать снимок".into());
        }
        for px in buf.chunks_exact_mut(4) {
            px.swap(0, 2); // BGRA -> RGBA
            px[3] = 255;
        }
        Ok((r.w as u32, r.h as u32, buf))
    }
}

/// Полноэкранный прозрачный оверлей для выделения области мышью.
pub async fn pick_area(app: &AppHandle, state: &Shared) -> Result<Region, String> {
    let mon = monitor_region();
    let (tx, rx) = tokio::sync::oneshot::channel();
    *state.area_tx.lock().unwrap() = Some(tx);
    let win = WebviewWindowBuilder::new(app, "select", WebviewUrl::App("select.html".into()))
        .transparent(true)
        .decorations(false)
        .always_on_top(true)
        .skip_taskbar(true)
        .shadow(false)
        .resizable(false)
        .build()
        .map_err(|e| e.to_string())?;
    let _ = win.set_position(PhysicalPosition::new(mon.x, mon.y));
    let _ = win.set_size(PhysicalSize::new(mon.w as u32, mon.h as u32));
    let _ = win.set_focus();
    let res = rx.await;
    let _ = win.close();
    let r = res.map_err(|e| e.to_string())?.ok_or("cancel")?;
    Ok(Region { x: mon.x + r.x, y: mon.y + r.y, ..r })
}

/// Вызывается оверлеем: выбранная область (относительно монитора) или null при отмене.
#[tauri::command]
pub fn area_done(state: State<Shared>, rect: Option<Region>) {
    if let Some(tx) = state.area_tx.lock().unwrap().take() {
        let _ = tx.send(rect.filter(|r| r.w >= 8 && r.h >= 8));
    }
}

#[derive(Serialize)]
pub struct Shot {
    pub path: String,
    pub thumb: String,
}

#[tauri::command]
pub async fn capture_screenshot(
    app: AppHandle,
    state: State<'_, Shared>,
    mode: String,
) -> Result<Shot, String> {
    let region = match mode.as_str() {
        "window" => foreground_region().ok_or("нет активного окна")?,
        "area" => pick_area(&app, &state).await?,
        _ => monitor_region(),
    };
    // даём оверлею выбора и острову исчезнуть с экрана
    tokio::time::sleep(Duration::from_millis(150)).await;
    let (w, h, rgba) = grab(region)?;

    let path = save_dir(&app, "image")?.join(format!("Скриншот {}.png", stamp()));
    let img = image::RgbaImage::from_raw(w, h, rgba.clone()).ok_or("ошибка изображения")?;
    img.save(&path).map_err(|e| e.to_string())?;

    // автокопирование в буфер обмена
    if let Ok(mut cb) = arboard::Clipboard::new() {
        let _ = cb.set_image(arboard::ImageData {
            width: w as usize,
            height: h as usize,
            bytes: std::borrow::Cow::Owned(rgba),
        });
    }

    // миниатюра для острова
    let th = image::imageops::thumbnail(&img, 96, 68);
    let mut png = Vec::new();
    th.write_to(&mut Cursor::new(&mut png), image::ImageFormat::Png)
        .map_err(|e| e.to_string())?;
    use base64::Engine;
    let thumb = format!("data:image/png;base64,{}", base64::engine::general_purpose::STANDARD.encode(png));

    Ok(Shot { path: path.display().to_string(), thumb })
}
