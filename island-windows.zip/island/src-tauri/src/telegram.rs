//! Telegram: вход под своим аккаунтом (MTProto, крейт grammers), чтобы видеть личные
//! сообщения и группы. Бот для этого не подходит — он не видит ваши чаты.
//! api_id / api_hash берутся на https://my.telegram.org (раздел API development tools).

use grammers_client::{
    session::Session,
    types::{Chat, LoginToken, PasswordToken},
    Client, Config, SignInError, Update,
};
use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{
    path::{Path, PathBuf},
    sync::atomic::{AtomicBool, Ordering},
    time::Duration,
};
use tauri::{AppHandle, Emitter, Manager, State};

use crate::Shared;

/// true, когда собственный клиент работает (чтобы не дублировать уведомления Telegram Desktop).
pub static ACTIVE: AtomicBool = AtomicBool::new(false);

#[derive(Default)]
pub struct Tg {
    client: Option<Client>,
    login: Option<LoginToken>,
    pw: Option<PasswordToken>,
}

#[derive(Serialize, Deserialize)]
struct Cfg {
    api_id: i32,
    api_hash: String,
}

fn dir(app: &AppHandle) -> PathBuf {
    let d = app.path().app_config_dir().unwrap_or_default();
    let _ = std::fs::create_dir_all(&d);
    d
}

async fn connect(d: &Path, api_id: i32, api_hash: String) -> Result<Client, String> {
    let session = Session::load_file_or_create(d.join("telegram.session")).map_err(|e| e.to_string())?;
    Client::connect(Config { session, api_id, api_hash, params: Default::default() })
        .await
        .map_err(|e| e.to_string())
}

/// Слушает новые входящие сообщения и отправляет их на остров.
fn run(app: AppHandle, client: Client) {
    ACTIVE.store(true, Ordering::SeqCst);
    tauri::async_runtime::spawn(async move {
        loop {
            match client.next_update().await {
                Ok(Update::NewMessage(m)) if !m.outgoing() => {
                    let chat = m.chat();
                    if matches!(chat, Chat::Channel(_)) {
                        continue; // каналы не показываем
                    }
                    let sender = m
                        .sender()
                        .map(|s| s.name().to_string())
                        .unwrap_or_else(|| chat.name().to_string());
                    let name = if matches!(chat, Chat::Group(_)) {
                        format!("{sender} · {}", chat.name())
                    } else {
                        sender
                    };
                    let mut text = m.text().to_string();
                    if text.trim().is_empty() {
                        text = "Вложение".into();
                    }
                    let _ = app.emit("tg", json!({ "name": name, "text": text }));
                }
                Ok(_) => {}
                Err(e) => {
                    eprintln!("island tg: {e}");
                    tokio::time::sleep(Duration::from_secs(5)).await;
                }
            }
        }
    });
}

fn finish(app: &AppHandle, client: &Client) {
    let _ = client.session().save_to_file(dir(app).join("telegram.session"));
    run(app.clone(), client.clone());
}

/// Автоподключение при запуске, если уже входили раньше.
pub fn autostart(app: AppHandle) {
    tauri::async_runtime::spawn(async move {
        let d = dir(&app);
        let Ok(txt) = std::fs::read_to_string(d.join("telegram.json")) else { return };
        let Ok(cfg) = serde_json::from_str::<Cfg>(&txt) else { return };
        let Ok(client) = connect(&d, cfg.api_id, cfg.api_hash).await else { return };
        if client.is_authorized().await.unwrap_or(false) {
            let state = app.state::<Shared>();
            state.tg.lock().await.client = Some(client.clone());
            run(app.clone(), client);
        }
    });
}

#[tauri::command]
pub fn tg_config(app: AppHandle) -> Option<serde_json::Value> {
    let txt = std::fs::read_to_string(dir(&app).join("telegram.json")).ok()?;
    serde_json::from_str(&txt).ok()
}

/// Возвращает "ok" (уже вошли) или "phone" (нужен вход по номеру).
#[tauri::command]
pub async fn tg_connect(
    app: AppHandle,
    state: State<'_, Shared>,
    api_id: i32,
    api_hash: String,
) -> Result<String, String> {
    let d = dir(&app);
    let cfg = serde_json::to_string(&Cfg { api_id, api_hash: api_hash.clone() }).map_err(|e| e.to_string())?;
    std::fs::write(d.join("telegram.json"), cfg).map_err(|e| e.to_string())?;
    let client = connect(&d, api_id, api_hash).await?;
    let authorized = client.is_authorized().await.map_err(|e| e.to_string())?;
    state.tg.lock().await.client = Some(client.clone());
    if authorized {
        finish(&app, &client);
        Ok("ok".into())
    } else {
        Ok("phone".into())
    }
}

#[tauri::command]
pub async fn tg_phone(state: State<'_, Shared>, phone: String) -> Result<(), String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let token = c.request_login_code(phone.trim()).await.map_err(|e| e.to_string())?;
    g.login = Some(token);
    Ok(())
}

/// Возвращает "ok" или "password" (включена двухфакторная защита).
#[tauri::command]
pub async fn tg_code(app: AppHandle, state: State<'_, Shared>, code: String) -> Result<String, String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let token = g.login.take().ok_or("сначала запросите код")?;
    match c.sign_in(&token, code.trim()).await {
        Ok(_) => {
            finish(&app, &c);
            Ok("ok".into())
        }
        Err(SignInError::PasswordRequired(p)) => {
            g.pw = Some(p);
            Ok("password".into())
        }
        Err(e) => {
            g.login = Some(token);
            Err(e.to_string())
        }
    }
}

#[tauri::command]
pub async fn tg_password(app: AppHandle, state: State<'_, Shared>, password: String) -> Result<(), String> {
    let mut g = state.tg.lock().await;
    let c = g.client.clone().ok_or("сначала подключитесь")?;
    let p = g.pw.take().ok_or("пароль не запрашивался")?;
    c.check_password(p, password.trim()).await.map_err(|e| e.to_string())?;
    finish(&app, &c);
    Ok(())
}
