//! Системные источники событий: музыка (SMTC), батарея, аудиоустройства,
//! уведомления Windows, загрузки браузера.

use base64::Engine;
use serde::Serialize;
use serde_json::json;
use std::{
    collections::{HashMap, HashSet},
    time::Duration,
};
use tauri::{AppHandle, Emitter, Manager};
use windows::Media::Control::{
    GlobalSystemMediaTransportControlsSessionManager as Mgr,
    GlobalSystemMediaTransportControlsSessionMediaProperties as Props,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus as PlayStatus,
};
use windows::core::Interface;
use windows::Storage::Streams::{DataReader, IRandomAccessStreamReference};

fn sleep(ms: u64) {
    std::thread::sleep(Duration::from_millis(ms));
}

// ───────────────────────── окно ─────────────────────────

pub fn cursor() -> Option<(i32, i32)> {
    use windows::Win32::{Foundation::POINT, UI::WindowsAndMessaging::GetCursorPos};
    let mut p = POINT::default();
    unsafe { GetCursorPos(&mut p).ok()? };
    Some((p.x, p.y))
}

/// Окно не забирает фокус, не появляется в Alt-Tab и не попадает в записи/скриншоты.
pub fn tune_window(win: &tauri::WebviewWindow) {
    use windows::Win32::{Foundation::HWND, UI::WindowsAndMessaging::*};
    let Ok(h) = win.hwnd() else { return };
    let hwnd = HWND(h.0 as _);
    unsafe {
        let ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
        SetWindowLongPtrW(
            hwnd,
            GWL_EXSTYLE,
            ex | WS_EX_NOACTIVATE.0 as isize | WS_EX_TOOLWINDOW.0 as isize,
        );
        let _ = SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
    }
}

pub fn start(app: AppHandle) {
    for f in [media_loop, battery_loop, devices_loop, notif_loop, downloads_loop] {
        let a = app.clone();
        std::thread::spawn(move || f(a));
    }
}

// ───────────────────────── музыка ─────────────────────────

#[derive(Serialize, Clone, PartialEq, Default)]
struct Media {
    title: String,
    artist: String,
    playing: bool,
    art: Option<String>,
}

fn read_thumb(p: &Props) -> windows::core::Result<Option<String>> {
    let Ok(t) = p.Thumbnail() else { return Ok(None) };
    stream_to_data_url(&t)
}

/// Картинка из потока WinRT → data URL для интерфейса.
fn stream_to_data_url(t: &IRandomAccessStreamReference) -> windows::core::Result<Option<String>> {
    let stream = t.OpenReadAsync()?.get()?;
    let size = stream.Size()? as u32;
    if size == 0 || size > 4_000_000 {
        return Ok(None);
    }
    let input = stream.GetInputStreamAt(0)?;
    let reader = DataReader::CreateDataReader(&input)?;
    reader.LoadAsync(size)?.get()?;
    let mut buf = vec![0u8; size as usize];
    reader.ReadBytes(&mut buf)?;
    let mime = stream.ContentType()?.to_string();
    let b64 = base64::engine::general_purpose::STANDARD.encode(buf);
    Ok(Some(format!("data:{mime};base64,{b64}")))
}

fn read_media(mgr: &Mgr, cache: &mut (String, Option<String>)) -> windows::core::Result<Media> {
    let s = mgr.GetCurrentSession()?;
    let p = s.TryGetMediaPropertiesAsync()?.get()?;
    let title = p.Title()?.to_string();
    let artist = p.Artist()?.to_string();
    let key = format!("{title}\u{1}{artist}");
    if cache.0 != key {
        *cache = (key, None);
    }
    if cache.1.is_none() {
        cache.1 = read_thumb(&p).ok().flatten();
    }
    let playing = s.GetPlaybackInfo()?.PlaybackStatus()? == PlayStatus::Playing;
    Ok(Media { title, artist, playing, art: cache.1.clone() })
}

fn media_loop(app: AppHandle) {
    let mgr = loop {
        match Mgr::RequestAsync().and_then(|o| o.get()) {
            Ok(m) => break m,
            Err(_) => sleep(3000),
        }
    };
    let mut cache = (String::new(), None);
    let mut last: Option<Media> = None;
    loop {
        let cur = read_media(&mgr, &mut cache).ok();
        if cur != last {
            let _ = match &cur {
                Some(m) => app.emit("media", m),
                None => app.emit("media", serde_json::Value::Null),
            };
            last = cur;
        }
        sleep(1000);
    }
}

#[tauri::command]
pub fn media_cmd(action: String) {
    // WinRT .get() нельзя вызывать в главном потоке — отдельный поток.
    std::thread::spawn(move || {
        let _ = (|| -> windows::core::Result<()> {
            let s = Mgr::RequestAsync()?.get()?.GetCurrentSession()?;
            match action.as_str() {
                "toggle" => drop(s.TryTogglePlayPauseAsync()?.get()?),
                "next" => drop(s.TrySkipNextAsync()?.get()?),
                "prev" => drop(s.TrySkipPreviousAsync()?.get()?),
                _ => {}
            }
            Ok(())
        })();
    });
}

// ───────────────────────── батарея ─────────────────────────

fn battery_loop(app: AppHandle) {
    use windows::Win32::System::Power::{GetSystemPowerStatus, SYSTEM_POWER_STATUS};
    let mut prev_ac: Option<bool> = None;
    let mut low_sent = false;
    loop {
        let mut st = SYSTEM_POWER_STATUS::default();
        let ok = unsafe { GetSystemPowerStatus(&mut st) }.is_ok();
        // BatteryFlag 128 — батареи нет; 255 — неизвестно
        if ok && st.BatteryFlag != 128 && st.BatteryLifePercent <= 100 {
            let ac = st.ACLineStatus == 1;
            let pct = st.BatteryLifePercent;
            if prev_ac == Some(!ac) && ac {
                let _ = app.emit("battery", json!({ "kind": "charging", "pct": pct }));
            }
            prev_ac = Some(ac);
            if !ac && pct <= 20 && !low_sent {
                low_sent = true;
                let _ = app.emit("battery", json!({ "kind": "low", "pct": pct }));
            }
            if ac || pct > 25 {
                low_sent = false;
            }
        }
        sleep(5000);
    }
}

// ───────────────────────── аудиоустройства ─────────────────────────

fn devices_loop(app: AppHandle) {
    use windows::{Devices::Enumeration::DeviceInformation, Media::Devices::MediaDevice};
    let mut known: Option<HashSet<String>> = None;
    loop {
        let found = (|| -> windows::core::Result<Vec<(String, String)>> {
            let sel = MediaDevice::GetAudioRenderSelector()?;
            let list = DeviceInformation::FindAllAsyncAqsFilter(&sel)?.get()?;
            let mut v = Vec::new();
            for d in list {
                v.push((d.Id()?.to_string(), d.Name()?.to_string()));
            }
            Ok(v)
        })();
        if let Ok(v) = found {
            if let Some(k) = &known {
                for (id, name) in &v {
                    if !k.contains(id) {
                        let _ = app.emit("device", json!({ "name": name }));
                    }
                }
            }
            known = Some(v.into_iter().map(|x| x.0).collect());
        }
        sleep(3000);
    }
}

// ───────────────────────── уведомления Windows ─────────────────────────
// Требует разрешения «Доступ к уведомлениям» и, как правило, приложения с package identity.
// Если доступ не выдан, поток тихо завершается.

fn notif_loop(app: AppHandle) {
    use windows::UI::Notifications::{
        Management::{UserNotificationListener, UserNotificationListenerAccessStatus},
        NotificationKinds,
    };
    let Ok(l) = UserNotificationListener::Current() else { return };
    let allowed = l
        .RequestAccessAsync()
        .and_then(|o| o.get())
        .map(|s| s == UserNotificationListenerAccessStatus::Allowed)
        .unwrap_or(false);
    if !allowed {
        eprintln!("island: доступ к уведомлениям Windows не выдан");
        return;
    }
    let mut seen: HashSet<u32> = HashSet::new();
    let mut icons: HashMap<String, Option<String>> = HashMap::new();
    let mut first = true;
    loop {
        if let Ok(list) = l.GetNotificationsAsync(NotificationKinds::Toast).and_then(|o| o.get()) {
            for n in list {
                let id = n.Id().unwrap_or(0);
                if !seen.insert(id) || first {
                    continue;
                }
                let name = n
                    .AppInfo()
                    .and_then(|a| a.DisplayInfo())
                    .and_then(|d| d.DisplayName())
                    .map(|s| s.to_string())
                    .unwrap_or_default();
                // Telegram показываем из собственного клиента, чтобы не дублировать
                if name.contains("Telegram") && crate::telegram::ACTIVE.load(std::sync::atomic::Ordering::SeqCst) {
                    continue;
                }
                let mut lines: Vec<String> = Vec::new();
                if let Ok(bindings) = n.Notification().and_then(|x| x.Visual()).and_then(|v| v.Bindings()) {
                    for b in bindings {
                        if let Ok(texts) = b.GetTextElements() {
                            for t in texts {
                                if let Ok(s) = t.Text() {
                                    lines.push(s.to_string());
                                }
                            }
                        }
                    }
                }
                // настоящая иконка приложения (кэшируем по имени)
                let icon = icons
                    .entry(name.clone())
                    .or_insert_with(|| app_icon(&n))
                    .clone();
                let title = lines.first().cloned().unwrap_or_default();
                let body = lines.iter().skip(1).cloned().collect::<Vec<_>>().join(" ");
                let _ = app.emit("winnotif", json!({ "app": name, "title": title, "body": body, "icon": icon }));
            }
        }
        first = false;
        sleep(1500);
    }
}

fn app_icon(n: &windows::UI::Notifications::UserNotification) -> Option<String> {
    let logo = n
        .AppInfo()
        .ok()?
        .DisplayInfo()
        .ok()?
        .GetLogo(windows::Foundation::Size { Width: 64.0, Height: 64.0 })
        .ok()?;
    let r: IRandomAccessStreamReference = logo.cast().ok()?;
    stream_to_data_url(&r).ok().flatten()
}

// ───────────────────────── загрузки ─────────────────────────
// Проводник не отдаёт прогресс копирования, поэтому следим за временными файлами
// браузеров в папке «Загрузки». Процента нет — только размер и факт завершения.

fn downloads_loop(app: AppHandle) {
    let Ok(dir) = app.path().download_dir() else { return };
    let exts = ["crdownload", "part", "opdownload", "download"];
    let mut active: HashMap<String, u64> = HashMap::new();
    loop {
        let mut now: HashMap<String, u64> = HashMap::new();
        if let Ok(rd) = std::fs::read_dir(&dir) {
            for e in rd.flatten() {
                let p = e.path();
                let ext = p.extension().and_then(|x| x.to_str()).unwrap_or("").to_lowercase();
                if exts.contains(&ext.as_str()) {
                    if let (Ok(m), Some(stem)) = (e.metadata(), p.file_stem().and_then(|s| s.to_str())) {
                        now.insert(stem.to_string(), m.len());
                    }
                }
            }
        }
        for (name, size) in &now {
            let _ = app.emit("download", json!({ "name": name, "size": size }));
        }
        for name in active.keys() {
            if !now.contains_key(name) {
                let _ = app.emit("download_done", json!({ "name": name }));
            }
        }
        active = now;
        sleep(1000);
    }
}
