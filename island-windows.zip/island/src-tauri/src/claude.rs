//! Интеграция с Claude Code через hooks.
//!
//! Хуки отправляют своё JSON-событие POST-ом на http://127.0.0.1:47890/hook (через curl).
//! Для событий, требующих решения (разрешение, вопрос с вариантами), ответ HTTP
//! задерживается, пока пользователь не нажмёт кнопку на острове; тело ответа curl
//! печатает в stdout, и Claude Code читает его как решение хука.

use serde_json::{json, Value};
use std::{io::Read, sync::atomic::Ordering, time::Duration};
use tauri::{AppHandle, Emitter, Manager, State};

use crate::Shared;

pub const PORT: u16 = 47890;

pub struct Pending {
    pub tx: std::sync::mpsc::Sender<String>,
}

pub fn start_server(app: AppHandle) {
    std::thread::spawn(move || {
        let Ok(server) = tiny_http::Server::http(format!("127.0.0.1:{PORT}")) else {
            eprintln!("island: порт {PORT} занят, интеграция с Claude Code отключена");
            return;
        };
        for mut req in server.incoming_requests() {
            let app = app.clone();
            std::thread::spawn(move || {
                let mut body = String::new();
                let _ = req.as_reader().read_to_string(&mut body);
                let out = handle(&app, &body);
                let _ = req.respond(tiny_http::Response::from_string(out));
            });
        }
    });
}

fn handle(app: &AppHandle, body: &str) -> String {
    let v: Value = serde_json::from_str(body).unwrap_or(Value::Null);
    let tool = v["tool_name"].as_str().unwrap_or("");
    match v["hook_event_name"].as_str().unwrap_or("") {
        "UserPromptSubmit" => {
            let _ = app.emit("claude", json!({ "kind": "working" }));
            String::new()
        }
        "Stop" => {
            let text = v["last_assistant_message"]
                .as_str()
                .map(String::from)
                .or_else(|| last_assistant_text(v["transcript_path"].as_str().unwrap_or("")))
                .unwrap_or_else(|| "Готово".into());
            let _ = app.emit("claude", json!({ "kind": "done", "text": text }));
            String::new()
        }
        // Вопросы с вариантами ответа приходят как PreToolUse для AskUserQuestion.
        "PreToolUse" if tool == "AskUserQuestion" => ask(app, &v),
        "PermissionRequest" => {
            // AskUserQuestion обрабатывается в PreToolUse; план-режим оставляем терминалу
            if tool == "AskUserQuestion" || tool == "ExitPlanMode" {
                return String::new();
            }
            perm(app, &v)
        }
        _ => String::new(),
    }
}

/// Отправляет событие на остров и ждёт ответа пользователя (до 110 с).
fn wait(app: &AppHandle, mut payload: Value) -> Option<String> {
    let sh = app.state::<Shared>();
    let id = format!("c{}", sh.counter.fetch_add(1, Ordering::SeqCst));
    let (tx, rx) = std::sync::mpsc::channel();
    sh.pending.lock().unwrap().insert(id.clone(), Pending { tx });
    payload["id"] = json!(id);
    let _ = app.emit("claude", payload);
    let res = rx.recv_timeout(Duration::from_secs(110)).ok();
    sh.pending.lock().unwrap().remove(&id);
    if res.is_none() {
        let _ = app.emit("claude", json!({ "kind": "cancel", "id": id }));
    }
    res
}

fn ask(app: &AppHandle, v: &Value) -> String {
    let input = v["tool_input"].clone();
    let qs = input["questions"].clone();
    // Поддерживаем только вопросы с одним вариантом; остальное — в терминале.
    let ok = qs.as_array().is_some_and(|a| {
        !a.is_empty() && a.iter().all(|q| !q["multiSelect"].as_bool().unwrap_or(false))
    });
    if !ok {
        return String::new();
    }
    match wait(app, json!({ "kind": "ask", "questions": qs })) {
        Some(ans) if ans != "terminal" => {
            let answers: Value = serde_json::from_str(&ans).unwrap_or_else(|_| json!({}));
            let mut upd = input;
            upd["answers"] = answers;
            json!({ "hookSpecificOutput": {
                "hookEventName": "PreToolUse",
                "permissionDecision": "allow",
                "updatedInput": upd
            }})
            .to_string()
        }
        _ => String::new(), // пустой ответ — Claude Code покажет обычный диалог в терминале
    }
}

fn perm(app: &AppHandle, v: &Value) -> String {
    let tool = v["tool_name"].as_str().unwrap_or("tool");
    let ti = &v["tool_input"];
    let detail = ti["command"]
        .as_str()
        .or(ti["file_path"].as_str())
        .or(ti["url"].as_str())
        .or(ti["pattern"].as_str())
        .map(String::from)
        .unwrap_or_else(|| ti.to_string());
    let decision = |d: Value| {
        json!({ "hookSpecificOutput": { "hookEventName": "PermissionRequest", "decision": d } }).to_string()
    };
    match wait(app, json!({ "kind": "perm", "tool": tool, "detail": detail })).as_deref() {
        Some("allow") => decision(json!({ "behavior": "allow" })),
        Some("deny") => decision(json!({ "behavior": "deny", "message": "Отклонено пользователем через Island" })),
        _ => String::new(),
    }
}

fn last_assistant_text(path: &str) -> Option<String> {
    let s = std::fs::read_to_string(path).ok()?;
    for line in s.lines().rev() {
        let Ok(v) = serde_json::from_str::<Value>(line) else { continue };
        if v["type"] != "assistant" {
            continue;
        }
        let text: String = v["message"]["content"]
            .as_array()?
            .iter()
            .filter(|c| c["type"] == "text")
            .filter_map(|c| c["text"].as_str())
            .collect::<Vec<_>>()
            .join("\n");
        if !text.trim().is_empty() {
            return Some(text);
        }
    }
    None
}

#[tauri::command]
pub fn claude_answer(state: State<Shared>, id: String, value: String) {
    if let Some(p) = state.pending.lock().unwrap().get(&id) {
        let _ = p.tx.send(value);
    }
}

/// Дописывает хуки в ~/.claude/settings.json (с резервной копией).
#[tauri::command]
pub fn install_claude_hooks(app: AppHandle) -> Result<String, String> {
    let dir = app.path().home_dir().map_err(|e| e.to_string())?.join(".claude");
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let path = dir.join("settings.json");
    let mut root: Value = if path.exists() {
        let text = std::fs::read_to_string(&path).map_err(|e| e.to_string())?;
        let _ = std::fs::copy(&path, dir.join("settings.json.island.bak"));
        if text.trim().is_empty() {
            json!({})
        } else {
            serde_json::from_str(&text).map_err(|e| format!("settings.json: {e}"))?
        }
    } else {
        json!({})
    };

    // (событие, matcher, таймаут curl в секундах)
    let events: [(&str, Option<&str>, u32); 4] = [
        ("UserPromptSubmit", None, 5),
        ("Stop", None, 5),
        ("PermissionRequest", None, 115),
        ("PreToolUse", Some("AskUserQuestion"), 115),
    ];
    let hooks = root
        .as_object_mut()
        .ok_or("settings.json: ожидался объект")?
        .entry("hooks")
        .or_insert_with(|| json!({}));
    for (ev, matcher, t) in events {
        let arr = hooks
            .as_object_mut()
            .ok_or("settings.json: поле hooks должно быть объектом")?
            .entry(ev)
            .or_insert_with(|| json!([]))
            .as_array_mut()
            .ok_or("settings.json: хуки события должны быть массивом")?;
        if arr.iter().any(|e| e.to_string().contains(&format!("127.0.0.1:{PORT}"))) {
            continue;
        }
        let cmd = format!("curl.exe -s -m {t} -X POST --data-binary @- http://127.0.0.1:{PORT}/hook");
        let mut entry = json!({ "hooks": [{ "type": "command", "command": cmd, "timeout": t + 5 }] });
        if let Some(m) = matcher {
            entry["matcher"] = json!(m);
        }
        arr.push(entry);
    }
    let out = serde_json::to_string_pretty(&root).map_err(|e| e.to_string())?;
    std::fs::write(&path, out).map_err(|e| e.to_string())?;
    Ok(path.display().to_string())
}
