//! Запись экрана.
//!
//! Видео: ffmpeg (gdigrab → H.264) отдельными сегментами — пауза = конец сегмента,
//! продолжение = новый сегмент. Звук ПК (WASAPI loopback) и микрофон пишутся через cpal
//! в отдельные WAV; выключение звука и пауза дают тишину, поэтому дорожки всегда
//! совпадают по длине с видео. При остановке всё склеивается ffmpeg в один MP4.
//!
//! Нужен ffmpeg.exe рядом с island.exe или в PATH.

use std::{
    io::Write,
    path::{Path, PathBuf},
    process::{Child, Command, Stdio},
    sync::{
        atomic::{AtomicBool, Ordering},
        Arc, Mutex,
    },
    time::{Duration, Instant},
};
use tauri::{AppHandle, State};

use crate::capture::{self, Region};
use crate::Shared;

pub fn ffmpeg_path() -> Option<PathBuf> {
    if let Some(dir) = std::env::current_exe().ok().and_then(|e| e.parent().map(|p| p.to_path_buf())) {
        let p = dir.join("ffmpeg.exe");
        if p.exists() {
            return Some(p);
        }
    }
    let paths = std::env::var_os("PATH")?;
    std::env::split_paths(&paths).map(|d| d.join("ffmpeg.exe")).find(|p| p.exists())
}

fn ff(path: &Path) -> Command {
    use std::os::windows::process::CommandExt;
    let mut c = Command::new(path);
    c.creation_flags(0x0800_0000); // CREATE_NO_WINDOW
    c
}

pub struct Recorder {
    ffmpeg: PathBuf,
    dir: PathBuf,
    out: PathBuf,
    region: Region,
    segs: Vec<PathBuf>,
    child: Option<Child>,
    paused: Arc<AtomicBool>,
    stop: Arc<AtomicBool>,
    sys_muted: Arc<AtomicBool>,
    mic_muted: Arc<AtomicBool>,
    threads: Vec<std::thread::JoinHandle<()>>,
    audio: Vec<PathBuf>,
}

// ───────────── видео-сегменты ─────────────

fn start_segment(r: &mut Recorder) -> Result<(), String> {
    let seg = r.dir.join(format!("seg{}.mp4", r.segs.len()));
    let (w, h) = (r.region.w & !1, r.region.h & !1); // для yuv420p размеры чётные
    let (ox, oy, size) = (r.region.x.to_string(), r.region.y.to_string(), format!("{w}x{h}"));
    let args: Vec<String> = [
        "-y", "-f", "gdigrab", "-framerate", "30", "-draw_mouse", "1",
        "-offset_x", ox.as_str(), "-offset_y", oy.as_str(), "-video_size", size.as_str(),
        "-i", "desktop",
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-pix_fmt", "yuv420p",
    ]
    .iter()
    .map(|s| s.to_string())
    .collect();
    let mut child = ff(&r.ffmpeg)
        .args(&args)
        .arg(&seg)
        .stdin(Stdio::piped())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .spawn()
        .map_err(|e| format!("ffmpeg: {e}"))?;
    std::thread::sleep(Duration::from_millis(700));
    if let Ok(Some(_)) = child.try_wait() {
        return Err("ffmpeg не смог начать запись".into());
    }
    r.segs.push(seg);
    r.child = Some(child);
    Ok(())
}

fn end_segment(r: &mut Recorder) {
    if let Some(mut c) = r.child.take() {
        if let Some(i) = c.stdin.as_mut() {
            let _ = i.write_all(b"q"); // корректное завершение ffmpeg
            let _ = i.flush();
        }
        let _ = c.wait();
    }
}

// ───────────── звук ─────────────

fn push(buf: &Mutex<Vec<f32>>, it: impl Iterator<Item = f32>, muted: &AtomicBool, paused: &AtomicBool) {
    if muted.load(Ordering::Relaxed) || paused.load(Ordering::Relaxed) {
        return;
    }
    buf.lock().unwrap().extend(it);
}

fn spawn_audio(
    loopback: bool,
    path: PathBuf,
    muted: Arc<AtomicBool>,
    paused: Arc<AtomicBool>,
    stop: Arc<AtomicBool>,
) -> Result<std::thread::JoinHandle<()>, String> {
    let (itx, irx) = std::sync::mpsc::channel::<Result<(), String>>();
    let h = std::thread::spawn(move || {
        use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
        // Stream нельзя переносить между потоками — создаём и держим его здесь.
        let built = (|| -> Result<(cpal::Stream, u32, u16, Arc<Mutex<Vec<f32>>>), String> {
            let host = cpal::default_host();
            let dev = if loopback { host.default_output_device() } else { host.default_input_device() }
                .ok_or("нет аудиоустройства")?;
            let cfg = if loopback { dev.default_output_config() } else { dev.default_input_config() }
                .map_err(|e| e.to_string())?;
            let (rate, ch, fmt) = (cfg.sample_rate().0, cfg.channels(), cfg.sample_format());
            let conf: cpal::StreamConfig = cfg.into();
            let buf = Arc::new(Mutex::new(Vec::<f32>::new()));
            let (b, m, p) = (buf.clone(), muted.clone(), paused.clone());
            let err = |e: cpal::StreamError| eprintln!("island audio: {e}");
            let stream = match fmt {
                cpal::SampleFormat::F32 => dev.build_input_stream(
                    &conf,
                    move |d: &[f32], _: &cpal::InputCallbackInfo| push(&b, d.iter().copied(), &m, &p),
                    err,
                    None,
                ),
                cpal::SampleFormat::I16 => dev.build_input_stream(
                    &conf,
                    move |d: &[i16], _: &cpal::InputCallbackInfo| {
                        push(&b, d.iter().map(|s| *s as f32 / 32768.0), &m, &p)
                    },
                    err,
                    None,
                ),
                _ => return Err("формат звука не поддерживается".into()),
            }
            .map_err(|e| e.to_string())?;
            stream.play().map_err(|e| e.to_string())?;
            Ok((stream, rate, ch, buf))
        })();

        match built {
            Err(e) => {
                let _ = itx.send(Err(e));
            }
            Ok((stream, rate, ch, buf)) => {
                let _ = itx.send(Ok(()));
                write_loop(rate, ch, &buf, &path, &paused, &stop);
                drop(stream);
            }
        }
    });
    irx.recv().map_err(|e| e.to_string())??;
    Ok(h)
}

/// Пишет WAV, дополняя тишиной до «активного времени» (без пауз) — так звук не уезжает от видео.
fn write_loop(rate: u32, ch: u16, buf: &Mutex<Vec<f32>>, path: &Path, paused: &AtomicBool, stop: &AtomicBool) {
    let spec = hound::WavSpec {
        channels: ch,
        sample_rate: rate,
        bits_per_sample: 32,
        sample_format: hound::SampleFormat::Float,
    };
    let Ok(mut w) = hound::WavWriter::create(path, spec) else { return };
    let mut active = Duration::ZERO;
    let mut last = Instant::now();
    let mut written: u64 = 0;
    loop {
        std::thread::sleep(Duration::from_millis(40));
        let now = Instant::now();
        if !paused.load(Ordering::Relaxed) {
            active += now - last;
        }
        last = now;
        let want = (active.as_secs_f64() * rate as f64) as u64 * ch as u64;
        let data = std::mem::take(&mut *buf.lock().unwrap());
        for s in &data {
            let _ = w.write_sample(*s);
        }
        written += data.len() as u64;
        while written < want {
            let _ = w.write_sample(0f32);
            written += 1;
        }
        if stop.load(Ordering::Relaxed) {
            break;
        }
    }
    let _ = w.finalize();
}

// ───────────── склейка ─────────────

fn mux(r: &Recorder) -> Result<(), String> {
    if r.segs.is_empty() {
        return Err("пустая запись".into());
    }
    let list = r.dir.join("list.txt");
    let txt: String = r
        .segs
        .iter()
        .map(|p| format!("file '{}'\n", p.to_string_lossy().replace('\\', "/")))
        .collect();
    std::fs::write(&list, txt).map_err(|e| e.to_string())?;

    let mut a: Vec<String> = ["-y", "-f", "concat", "-safe", "0", "-i"].map(String::from).to_vec();
    a.push(list.to_string_lossy().into());
    for f in &r.audio {
        a.push("-i".into());
        a.push(f.to_string_lossy().into());
    }
    let tail: &[&str] = match r.audio.len() {
        0 => &["-c", "copy"],
        1 => &["-map", "0:v", "-map", "1:a", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest"],
        _ => &[
            "-filter_complex", "[1:a][2:a]amix=inputs=2:duration=longest:normalize=0[a]",
            "-map", "0:v", "-map", "[a]", "-c:v", "copy", "-c:a", "aac", "-b:a", "160k", "-shortest",
        ],
    };
    a.extend(tail.iter().map(|s| s.to_string()));
    a.push(r.out.to_string_lossy().into());

    let st = ff(&r.ffmpeg)
        .args(&a)
        .stdin(Stdio::null())
        .stdout(Stdio::null())
        .stderr(Stdio::null())
        .status()
        .map_err(|e| e.to_string())?;
    if st.success() {
        Ok(())
    } else {
        Err("ffmpeg не смог собрать итоговый файл".into())
    }
}

// ───────────── команды ─────────────

/// Выбор области записи (для «Область» показывается оверлей выделения).
#[tauri::command]
pub async fn rec_prepare(app: AppHandle, state: State<'_, Shared>, mode: String) -> Result<(), String> {
    if ffmpeg_path().is_none() {
        return Err("не найден ffmpeg.exe".into());
    }
    let region = match mode.as_str() {
        "window" => capture::foreground_region().ok_or("нет активного окна")?,
        "area" => capture::pick_area(&app, &state).await?,
        _ => capture::monitor_region(),
    };
    *state.region.lock().unwrap() = Some(region);
    Ok(())
}

/// Старт записи. `sys` / `mic` — включён ли звук в начале (потом переключается rec_mute).
#[tauri::command]
pub async fn rec_start(app: AppHandle, state: State<'_, Shared>, sys: bool, mic: bool) -> Result<(), String> {
    if state.rec.lock().unwrap().is_some() {
        return Err("запись уже идёт".into());
    }
    let region = state.region.lock().unwrap().take().ok_or("область не выбрана")?;
    let ffmpeg = ffmpeg_path().ok_or("не найден ffmpeg.exe")?;
    let dir = std::env::temp_dir().join(format!("island-rec-{}", capture::stamp()));
    std::fs::create_dir_all(&dir).map_err(|e| e.to_string())?;
    let out = capture::save_dir(&app, "video")?.join(format!("Запись {}.mp4", capture::stamp()));

    let mut rec = Recorder {
        ffmpeg,
        dir: dir.clone(),
        out,
        region,
        segs: vec![],
        child: None,
        paused: Arc::new(AtomicBool::new(false)),
        stop: Arc::new(AtomicBool::new(false)),
        sys_muted: Arc::new(AtomicBool::new(!sys)),
        mic_muted: Arc::new(AtomicBool::new(!mic)),
        threads: vec![],
        audio: vec![],
    };
    start_segment(&mut rec)?; // сначала видео, чтобы звук не опережал

    for (loopback, name, muted) in [(true, "sys.wav", rec.sys_muted.clone()), (false, "mic.wav", rec.mic_muted.clone())] {
        let path = dir.join(name);
        match spawn_audio(loopback, path.clone(), muted, rec.paused.clone(), rec.stop.clone()) {
            Ok(h) => {
                rec.threads.push(h);
                rec.audio.push(path);
            }
            Err(e) => eprintln!("island: {name}: {e}"), // нет устройства — пишем без этой дорожки
        }
    }
    *state.rec.lock().unwrap() = Some(rec);
    Ok(())
}

#[tauri::command]
pub async fn rec_pause(state: State<'_, Shared>, paused: bool) -> Result<(), String> {
    let mut g = state.rec.lock().unwrap();
    let r = g.as_mut().ok_or("запись не идёт")?;
    r.paused.store(paused, Ordering::Relaxed);
    if paused {
        end_segment(r);
        Ok(())
    } else {
        start_segment(r)
    }
}

#[tauri::command]
pub fn rec_mute(state: State<Shared>, which: String, muted: bool) {
    if let Some(r) = state.rec.lock().unwrap().as_ref() {
        let flag = if which == "sys" { &r.sys_muted } else { &r.mic_muted };
        flag.store(muted, Ordering::Relaxed);
    }
}

/// Остановка: склейка сегментов и звука, возвращает путь к файлу.
#[tauri::command]
pub async fn rec_stop(state: State<'_, Shared>) -> Result<String, String> {
    let mut r = state.rec.lock().unwrap().take().ok_or("запись не идёт")?;
    end_segment(&mut r);
    r.stop.store(true, Ordering::Relaxed);
    for t in r.threads.drain(..) {
        let _ = t.join();
    }
    let res = mux(&r);
    let _ = std::fs::remove_dir_all(&r.dir);
    res.map(|_| r.out.display().to_string())
}
