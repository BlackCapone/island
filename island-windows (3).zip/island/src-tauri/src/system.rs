//! Системные источники событий: музыка (SMTC), батарея, аудиоустройства,
//! уведомления Windows, загрузки браузера.

use base64::Engine;
use serde::Serialize;
use serde_json::json;
use std::{
    collections::{HashMap, HashSet},
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use tauri::{AppHandle, Emitter, Manager};
use windows::Media::Control::{
    GlobalSystemMediaTransportControlsSessionManager as Mgr,
    GlobalSystemMediaTransportControlsSessionMediaProperties as Props,
    GlobalSystemMediaTransportControlsSessionPlaybackStatus as PlayStatus,
};
use windows::core::Interface;
use windows::Storage::Streams::{DataReader, IRandomAccessStreamReference};

fn sleep(ms: u64) {
    std::thread::sleep(Duration::from_millis(ms));
}

// ───────────────────────── окно ─────────────────────────

pub fn cursor() -> Option<(i32, i32)> {
    use windows::Win32::{Foundation::POINT, UI::WindowsAndMessaging::GetCursorPos};
    let mut p = POINT::default();
    unsafe { GetCursorPos(&mut p).ok()? };
    Some((p.x, p.y))
}

/// Окно не забирает фокус, не появляется в Alt-Tab и не попадает в записи/скриншоты.
pub fn tune_window(win: &tauri::WebviewWindow) {
    use windows::Win32::{Foundation::HWND, UI::WindowsAndMessaging::*};
    let Ok(h) = win.hwnd() else { return };
    let hwnd = HWND(h.0 as _);
    unsafe {
        let ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
        SetWindowLongPtrW(
            hwnd,
            GWL_EXSTYLE,
            ex | WS_EX_NOACTIVATE.0 as isize | WS_EX_TOOLWINDOW.0 as isize,
        );
        let _ = SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE);
    }
}

pub fn start(app: AppHandle) {
    for f in [media_loop, battery_loop, devices_loop, bt_loop, radio_loop, vpn_loop, btbattery_loop, notif_loop, downloads_loop] {
        let a = app.clone();
        std::thread::spawn(move || f(a));
    }
}

// ───────────────────────── музыка ─────────────────────────

#[derive(Serialize, Clone, PartialEq, Default)]
struct Media {
    title: String,
    artist: String,
    playing: bool,
    art: Option<String>,
}

fn read_thumb(p: &Props) -> windows::core::Result<Option<String>> {
    let Ok(t) = p.Thumbnail() else { return Ok(None) };
    stream_to_data_url(&t)
}

/// Картинка из потока WinRT → data URL для интерфейса.
fn stream_to_data_url(t: &IRandomAccessStreamReference) -> windows::core::Result<Option<String>> {
    let stream = t.OpenReadAsync()?.get()?;
    let size = stream.Size()? as u32;
    if size == 0 || size > 4_000_000 {
        return Ok(None);
    }
    let input = stream.GetInputStreamAt(0)?;
    let reader = DataReader::CreateDataReader(&input)?;
    reader.LoadAsync(size)?.get()?;
    let mut buf = vec![0u8; size as usize];
    reader.ReadBytes(&mut buf)?;
    let mime = stream.ContentType()?.to_string();
    let b64 = base64::engine::general_purpose::STANDARD.encode(buf);
    Ok(Some(format!("data:{mime};base64,{b64}")))
}

fn read_media(mgr: &Mgr, cache: &mut (String, Option<String>)) -> windows::core::Result<Media> {
    let s = mgr.GetCurrentSession()?;
    let p = s.TryGetMediaPropertiesAsync()?.get()?;
    let title = p.Title()?.to_string();
    let artist = p.Artist()?.to_string();
    let key = format!("{title}\u{1}{artist}");
    if cache.0 != key {
        *cache = (key, None);
    }
    if cache.1.is_none() {
        cache.1 = read_thumb(&p).ok().flatten();
    }
    let playing = s.GetPlaybackInfo()?.PlaybackStatus()? == PlayStatus::Playing;
    Ok(Media { title, artist, playing, art: cache.1.clone() })
}

fn media_loop(app: AppHandle) {
    let mgr = loop {
        match Mgr::RequestAsync().and_then(|o| o.get()) {
            Ok(m) => break m,
            Err(_) => sleep(3000),
        }
    };
    let mut cache = (String::new(), None);
    let mut last: Option<Media> = None;
    loop {
        let cur = read_media(&mgr, &mut cache).ok();
        if cur != last {
            let _ = match &cur {
                Some(m) => app.emit("media", m),
                None => app.emit("media", serde_json::Value::Null),
            };
            last = cur;
        }
        sleep(1000);
    }
}

#[tauri::command]
pub fn media_cmd(action: String) {
    // WinRT .get() нельзя вызывать в главном потоке — отдельный поток.
    std::thread::spawn(move || {
        let _ = (|| -> windows::core::Result<()> {
            let s = Mgr::RequestAsync()?.get()?.GetCurrentSession()?;
            match action.as_str() {
                "toggle" => drop(s.TryTogglePlayPauseAsync()?.get()?),
                "next" => drop(s.TrySkipNextAsync()?.get()?),
                "prev" => drop(s.TrySkipPreviousAsync()?.get()?),
                _ => {}
            }
            Ok(())
        })();
    });
}

// ───────────────────────── батарея ─────────────────────────

fn battery_loop(app: AppHandle) {
    use windows::Win32::System::Power::{GetSystemPowerStatus, SYSTEM_POWER_STATUS};
    let mut prev_ac: Option<bool> = None;
    let mut low_sent = false;
    loop {
        let mut st = SYSTEM_POWER_STATUS::default();
        let ok = unsafe { GetSystemPowerStatus(&mut st) }.is_ok();
        // BatteryFlag 128 — батареи нет; 255 — неизвестно
        if ok && st.BatteryFlag != 128 && st.BatteryLifePercent <= 100 {
            let ac = st.ACLineStatus == 1;
            let pct = st.BatteryLifePercent;
            if prev_ac == Some(!ac) && ac {
                let _ = app.emit("battery", json!({ "kind": "charging", "pct": pct }));
            }
            prev_ac = Some(ac);
            if !ac && pct <= 20 && !low_sent {
                low_sent = true;
                let _ = app.emit("battery", json!({ "kind": "low", "pct": pct }));
            }
            if ac || pct > 25 {
                low_sent = false;
            }
        }
        sleep(5000);
    }
}

// ───────────────────────── аудиоустройства (проводные) ─────────────────────────

static LAST_BT: AtomicU64 = AtomicU64::new(0);

fn now_secs() -> u64 {
    SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0)
}

fn devices_loop(app: AppHandle) {
    use windows::{Devices::Enumeration::DeviceInformation, Media::Devices::MediaDevice};
    let mut known: Option<HashSet<String>> = None;
    loop {
        let found = (|| -> windows::core::Result<Vec<(String, String)>> {
            let sel = MediaDevice::GetAudioRenderSelector()?;
            let list = DeviceInformation::FindAllAsyncAqsFilter(&sel)?.get()?;
            let mut v = Vec::new();
            for d in list {
                v.push((d.Id()?.to_string(), d.Name()?.to_string()));
            }
            Ok(v)
        })();
        if let Ok(v) = found {
            if let Some(k) = &known {
                for (id, name) in &v {
                    if !k.contains(id) {
                        // Bluetooth-устройства объявляет bt_loop; здесь только проводные/HDMI,
                        // поэтому ждём и пропускаем, если недавно подключилось Bluetooth-устройство
                        sleep(5000);
                        if now_secs().saturating_sub(LAST_BT.load(Ordering::SeqCst)) > 20 {
                            let _ = app.emit("device", json!({ "name": name, "cls": "audio", "on": true }));
                        }
                    }
                }
            }
            known = Some(v.into_iter().map(|x| x.0).collect());
        }
        sleep(3000);
    }
}

// ───────────────────────── Bluetooth-устройства: подключение / отключение ─────────────────────────

fn bt_class(id: &windows::core::HSTRING) -> String {
    use windows::Devices::Bluetooth::{BluetoothDevice, BluetoothMajorClass as C};
    (|| -> windows::core::Result<String> {
        let m = BluetoothDevice::FromIdAsync(id)?.get()?.ClassOfDevice()?.MajorClass()?;
        Ok(if m == C::AudioVideo {
            "audio"
        } else if m == C::Peripheral {
            "input"
        } else if m == C::Phone {
            "phone"
        } else if m == C::Computer {
            "pc"
        } else if m == C::Wearable {
            "watch"
        } else {
            "bt"
        }
        .to_string())
    })()
    .unwrap_or_else(|_| "bt".into())
}

/// Имя → тип для всех сейчас подключённых Bluetooth-устройств (обычные и Low Energy).
fn scan_bt(cache: &mut HashMap<String, String>) -> windows::core::Result<HashMap<String, String>> {
    use windows::Devices::{
        Bluetooth::{BluetoothConnectionStatus as St, BluetoothDevice, BluetoothLEDevice},
        Enumeration::DeviceInformation,
    };
    let mut now = HashMap::new();
    let classic = BluetoothDevice::GetDeviceSelectorFromConnectionStatus(St::Connected)?;
    for d in DeviceInformation::FindAllAsyncAqsFilter(&classic)?.get()? {
        let name = d.Name()?.to_string();
        if name.trim().is_empty() {
            continue;
        }
        let cls = cache.entry(name.clone()).or_insert_with(|| bt_class(&d.Id().unwrap_or_default())).clone();
        now.insert(name, cls);
    }
    let le = BluetoothLEDevice::GetDeviceSelectorFromConnectionStatus(St::Connected)?;
    for d in DeviceInformation::FindAllAsyncAqsFilter(&le)?.get()? {
        let name = d.Name()?.to_string();
        if !name.trim().is_empty() {
            now.entry(name).or_insert_with(|| "input".to_string());
        }
    }
    Ok(now)
}

fn bt_loop(app: AppHandle) {
    let mut cache: HashMap<String, String> = HashMap::new();
    let mut known: Option<HashMap<String, String>> = None;
    loop {
        if let Ok(now) = scan_bt(&mut cache) {
            if let Some(prev) = &known {
                for (name, cls) in &now {
                    if !prev.contains_key(name) {
                        LAST_BT.store(now_secs(), Ordering::SeqCst);
                        let _ = app.emit("device", json!({ "name": name, "cls": cls, "on": true }));
                    }
                }
                for (name, cls) in prev {
                    if !now.contains_key(name) {
                        let _ = app.emit("device", json!({ "name": name, "cls": cls, "on": false }));
                    }
                }
            }
            known = Some(now);
        }
        sleep(3000);
    }
}

// ───────────────────────── Wi-Fi и Bluetooth: включение / выключение ─────────────────────────

fn radio_loop(app: AppHandle) {
    use windows::Devices::Radios::{Radio, RadioKind, RadioState};
    let mut last: HashMap<&'static str, bool> = HashMap::new();
    loop {
        if let Ok(list) = Radio::GetRadiosAsync().and_then(|o| o.get()) {
            for r in list {
                let Ok(k) = r.Kind() else { continue };
                let kind = if k == RadioKind::Bluetooth {
                    "bluetooth"
                } else if k == RadioKind::WiFi {
                    "wifi"
                } else {
                    continue;
                };
                let on = r.State().map(|s| s == RadioState::On).unwrap_or(false);
                if let Some(&prev) = last.get(kind) {
                    if prev != on {
                        let _ = app.emit("radio", json!({ "kind": kind, "on": on }));
                    }
                }
                last.insert(kind, on);
            }
        }
        sleep(2000);
    }
}

// ───────────────────────── VPN: подключение / отключение ─────────────────────────
// Ищем поднятые сетевые адаптеры VPN: встроенный VPN Windows (PPP) и TUN-адаптеры
// WireGuard, OpenVPN, Nord, Proton, Hiddify, Clash и т. п. VPN в режиме «системный прокси»
// адаптера не создаёт, его определить нельзя.

fn is_vpn(if_type: u32, name: &str, desc: &str) -> bool {
    const SKIP: &[&str] = &[
        "teredo", "isatap", "6to4", "vethernet", "vmware", "virtualbox", "hyper-v", "loopback", "bluetooth",
        "wi-fi direct", "wsl", "docker",
    ];
    const KW: &[&str] = &[
        "vpn", "wintun", "wireguard", "openvpn", "tap-windows", "nordlynx", "nordvpn", "protonvpn", "mullvad", "warp",
        "tailscale", "zerotier", "hiddify", "clash", "v2ray", "xray", "sing-box", "surfshark", "anyconnect",
        "fortinet", "pritunl",
    ];
    let s = format!("{name} {desc}").to_lowercase();
    if SKIP.iter().any(|k| s.contains(k)) {
        return false;
    }
    if if_type == 23 {
        return true; // PPP — встроенный VPN Windows
    }
    KW.iter().any(|k| s.contains(k)) || s.split(|c: char| !c.is_alphanumeric()).any(|w| w == "tun" || w == "tap")
}

fn vpn_adapters() -> Vec<String> {
    use windows::Win32::{
        NetworkManagement::{
            IpHelper::{
                GetAdaptersAddresses, GAA_FLAG_SKIP_ANYCAST, GAA_FLAG_SKIP_DNS_SERVER, GAA_FLAG_SKIP_MULTICAST,
                IP_ADAPTER_ADDRESSES_LH,
            },
            Ndis::IfOperStatusUp,
        },
        Networking::WinSock::AF_UNSPEC,
    };
    let flags = GAA_FLAG_SKIP_ANYCAST | GAA_FLAG_SKIP_MULTICAST | GAA_FLAG_SKIP_DNS_SERVER;
    let mut size: u32 = 0;
    unsafe {
        GetAdaptersAddresses(AF_UNSPEC.0 as u32, flags, None, None, &mut size);
        let mut buf = vec![0u64; size as usize / 8 + 256]; // u64 — для выравнивания структуры
        size = (buf.len() * 8) as u32;
        let first = buf.as_mut_ptr() as *mut IP_ADAPTER_ADDRESSES_LH;
        if GetAdaptersAddresses(AF_UNSPEC.0 as u32, flags, None, Some(first), &mut size) != 0 {
            return Vec::new();
        }
        let mut out = Vec::new();
        let mut cur = first;
        while !cur.is_null() {
            let a = &*cur;
            if a.OperStatus == IfOperStatusUp {
                let name = a.FriendlyName.to_string().unwrap_or_default();
                let desc = a.Description.to_string().unwrap_or_default();
                if is_vpn(a.IfType, &name, &desc) {
                    out.push(name);
                }
            }
            cur = a.Next;
        }
        out
    }
}

fn vpn_loop(app: AppHandle) {
    let mut state: Option<bool> = None;
    let mut pending: Option<(bool, u8)> = None;
    let mut last_name = String::new();
    loop {
        let list = vpn_adapters();
        let on = !list.is_empty();
        if let Some(n) = list.first() {
            last_name = n.clone();
        }
        match state {
            None => state = Some(on), // первый опрос — без уведомления
            Some(s) if s == on => pending = None,
            Some(_) => {
                // меняем состояние только если оно продержалось два опроса подряд (защита от «дребезга»)
                let n = match pending {
                    Some((p, n)) if p == on => n + 1,
                    _ => 1,
                };
                pending = Some((on, n));
                if n >= 2 {
                    state = Some(on);
                    pending = None;
                    let _ = app.emit("vpn", json!({ "on": on, "name": last_name }));
                }
            }
        }
        sleep(1500);
    }
}

// ───────────────────────── заряд Bluetooth-наушников ─────────────────────────
// Windows хранит заряд у устройства в свойстве {104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2 (байт, проценты) —
// именно его показывает «Параметры → Bluetooth и устройства». Читаем через PowerShell раз в минуту.
// Работает для устройств, которые сообщают заряд Windows (то, что видно в Параметрах).

const BT_SCRIPT: &str = r#"[Console]::OutputEncoding=[Text.Encoding]::UTF8
Get-PnpDevice -Class Bluetooth -PresentOnly -ErrorAction SilentlyContinue | ForEach-Object {
  $id = $_.InstanceId
  $c = (Get-PnpDeviceProperty -InstanceId $id -KeyName '{83DA6326-97A6-4088-9453-A1923F573B29} 15' -ErrorAction SilentlyContinue).Data
  $b = (Get-PnpDeviceProperty -InstanceId $id -KeyName '{104EA319-6EE2-4701-BD47-8DDBF425BBE5} 2' -ErrorAction SilentlyContinue).Data
  if ($c -eq $true -and $null -ne $b) { "$($_.FriendlyName)|$b" }
}"#;

fn run_powershell(script: &str) -> String {
    use std::os::windows::process::CommandExt;
    let utf16: Vec<u8> = script.encode_utf16().flat_map(|u| u.to_le_bytes()).collect();
    let enc = base64::engine::general_purpose::STANDARD.encode(utf16);
    std::process::Command::new("powershell")
        .args(["-NoProfile", "-NonInteractive", "-EncodedCommand", &enc])
        .creation_flags(0x0800_0000) // без окна консоли
        .output()
        .map(|o| String::from_utf8_lossy(&o.stdout).into_owned())
        .unwrap_or_default()
}

fn btbattery_loop(app: AppHandle) {
    let mut last: HashMap<String, u8> = HashMap::new();
    loop {
        let mut now: HashMap<String, u8> = HashMap::new();
        for line in run_powershell(BT_SCRIPT).lines() {
            if let Some((name, pct)) = line.rsplit_once('|') {
                if let (Ok(p), false) = (pct.trim().parse::<u8>(), name.trim().is_empty()) {
                    now.insert(name.trim().to_string(), p.min(100));
                }
            }
        }
        for (name, &p) in &now {
            // сообщаем: при первом появлении (подключение) и при падении ниже 20% / 10%
            let show = match last.get(name) {
                None => true,
                Some(&o) => (p <= 20 && o > 20) || (p <= 10 && o > 10),
            };
            if show {
                let _ = app.emit("btbattery", json!({ "name": name, "pct": p }));
            }
        }
        last = now; // отключённые пропадают из списка и снова показываются при подключении
        sleep(60_000);
    }
}

// ───────────────────────── уведомления Windows ─────────────────────────
// Требует разрешения «Доступ к уведомлениям» и, как правило, приложения с package identity.
// Если доступ не выдан, поток тихо завершается.

fn notif_loop(app: AppHandle) {
    use windows::UI::Notifications::{
        Management::{UserNotificationListener, UserNotificationListenerAccessStatus},
        NotificationKinds,
    };
    let Ok(l) = UserNotificationListener::Current() else { return };
    let allowed = l
        .RequestAccessAsync()
        .and_then(|o| o.get())
        .map(|s| s == UserNotificationListenerAccessStatus::Allowed)
        .unwrap_or(false);
    if !allowed {
        eprintln!("island: доступ к уведомлениям Windows не выдан");
        return;
    }
    let mut seen: HashSet<u32> = HashSet::new();
    let mut icons: HashMap<String, Option<String>> = HashMap::new();
    let mut first = true;
    loop {
        if let Ok(list) = l.GetNotificationsAsync(NotificationKinds::Toast).and_then(|o| o.get()) {
            for n in list {
                let id = n.Id().unwrap_or(0);
                if !seen.insert(id) || first {
                    continue;
                }
                let name = n
                    .AppInfo()
                    .and_then(|a| a.DisplayInfo())
                    .and_then(|d| d.DisplayName())
                    .map(|s| s.to_string())
                    .unwrap_or_default();
                // Telegram показываем из собственного клиента, чтобы не дублировать
                if name.contains("Telegram") && crate::telegram::ACTIVE.load(std::sync::atomic::Ordering::SeqCst) {
                    continue;
                }
                let mut lines: Vec<String> = Vec::new();
                if let Ok(bindings) = n.Notification().and_then(|x| x.Visual()).and_then(|v| v.Bindings()) {
                    for b in bindings {
                        if let Ok(texts) = b.GetTextElements() {
                            for t in texts {
                                if let Ok(s) = t.Text() {
                                    lines.push(s.to_string());
                                }
                            }
                        }
                    }
                }
                // настоящая иконка приложения (кэшируем по имени)
                let icon = icons
                    .entry(name.clone())
                    .or_insert_with(|| app_icon(&n))
                    .clone();
                let title = lines.first().cloned().unwrap_or_default();
                let body = lines.iter().skip(1).cloned().collect::<Vec<_>>().join(" ");
                let _ = app.emit("winnotif", json!({ "app": name, "title": title, "body": body, "icon": icon }));
            }
        }
        first = false;
        sleep(1500);
    }
}

fn app_icon(n: &windows::UI::Notifications::UserNotification) -> Option<String> {
    let logo = n
        .AppInfo()
        .ok()?
        .DisplayInfo()
        .ok()?
        .GetLogo(windows::Foundation::Size { Width: 64.0, Height: 64.0 })
        .ok()?;
    let r: IRandomAccessStreamReference = logo.cast().ok()?;
    stream_to_data_url(&r).ok().flatten()
}

// ───────────────────────── загрузки ─────────────────────────
// Проводник не отдаёт прогресс копирования, поэтому следим за временными файлами
// браузеров в папке «Загрузки». Процента нет — только размер и факт завершения.

fn downloads_loop(app: AppHandle) {
    let Ok(dir) = app.path().download_dir() else { return };
    let exts = ["crdownload", "part", "opdownload", "download"];
    let mut active: HashMap<String, u64> = HashMap::new();
    loop {
        let mut now: HashMap<String, u64> = HashMap::new();
        if let Ok(rd) = std::fs::read_dir(&dir) {
            for e in rd.flatten() {
                let p = e.path();
                let ext = p.extension().and_then(|x| x.to_str()).unwrap_or("").to_lowercase();
                if exts.contains(&ext.as_str()) {
                    if let (Ok(m), Some(stem)) = (e.metadata(), p.file_stem().and_then(|s| s.to_str())) {
                        now.insert(stem.to_string(), m.len());
                    }
                }
            }
        }
        for (name, size) in &now {
            let _ = app.emit("download", json!({ "name": name, "size": size }));
        }
        for name in active.keys() {
            if !now.contains_key(name) {
                let _ = app.emit("download_done", json!({ "name": name }));
            }
        }
        active = now;
        sleep(1000);
    }
}
