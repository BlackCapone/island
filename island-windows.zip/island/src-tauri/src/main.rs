#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod capture;
mod claude;
mod record;
mod system;
mod telegram;

use std::{
    collections::HashMap,
    sync::{atomic::AtomicU64, Mutex},
    time::Duration,
};
use tauri::menu::{Menu, MenuItem};
use tauri::tray::TrayIconBuilder;
use tauri::{
    AppHandle, Emitter, Manager, PhysicalPosition, State, WebviewUrl, WebviewWindow,
    WebviewWindowBuilder,
};
use tauri_plugin_autostart::{MacosLauncher, ManagerExt};

/// Общее состояние приложения.
pub struct Shared {
    /// Текущий размер острова в CSS-пикселях (ширина, высота) — для click-through.
    pub rect: Mutex<(f64, f64)>,
    /// Ожидающие ответа запросы от Claude Code (разрешения / вопросы).
    pub pending: Mutex<HashMap<String, claude::Pending>>,
    pub counter: AtomicU64,
    /// Канал результата выбора области экрана.
    pub area_tx: Mutex<Option<tokio::sync::oneshot::Sender<Option<capture::Region>>>>,
    /// Область, выбранная перед началом записи.
    pub region: Mutex<Option<capture::Region>>,
    pub rec: Mutex<Option<record::Recorder>>,
    pub tg: tokio::sync::Mutex<telegram::Tg>,
}

impl Shared {
    fn new() -> Self {
        Self {
            rect: Mutex::new((150.0, 36.0)),
            pending: Default::default(),
            counter: AtomicU64::new(1),
            area_tx: Default::default(),
            region: Default::default(),
            rec: Default::default(),
            tg: Default::default(),
        }
    }
}

#[tauri::command]
fn set_rect(state: State<Shared>, w: f64, h: f64) {
    *state.rect.lock().unwrap() = (w, h);
}

#[tauri::command]
fn open_folder(app: AppHandle, kind: String) -> Result<(), String> {
    let dir = capture::save_dir(&app, &kind)?;
    std::process::Command::new("explorer")
        .arg(dir)
        .spawn()
        .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
fn autostart_get(app: AppHandle) -> bool {
    app.autolaunch().is_enabled().unwrap_or(false)
}

#[tauri::command]
fn autostart_set(app: AppHandle, on: bool) -> Result<(), String> {
    let m = app.autolaunch();
    let r = if on { m.enable() } else { m.disable() };
    r.map_err(|e| e.to_string())
}

#[tauri::command]
fn check_ffmpeg() -> Result<String, String> {
    record::ffmpeg_path()
        .map(|p| p.display().to_string())
        .ok_or_else(|| "ffmpeg не найден".to_string())
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_autostart::init(MacosLauncher::LaunchAgent, None))
        .manage(Shared::new())
        .invoke_handler(tauri::generate_handler![
            set_rect,
            open_folder,
            autostart_get,
            autostart_set,
            check_ffmpeg,
            system::media_cmd,
            claude::claude_answer,
            claude::install_claude_hooks,
            capture::capture_screenshot,
            capture::area_done,
            record::rec_prepare,
            record::rec_start,
            record::rec_pause,
            record::rec_mute,
            record::rec_stop,
            telegram::tg_config,
            telegram::tg_connect,
            telegram::tg_phone,
            telegram::tg_code,
            telegram::tg_password,
        ])
        .setup(|app| {
            let handle = app.handle().clone();
            setup_window(&handle)?;
            setup_tray(&handle)?;
            claude::start_server(handle.clone());
            system::start(handle.clone());
            telegram::autostart(handle.clone());
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("ошибка запуска Island");
}

fn setup_window(app: &AppHandle) -> tauri::Result<()> {
    let win = app.get_webview_window("main").expect("main window");
    if let Some(m) = win.primary_monitor()? {
        let w = win.outer_size()?.width as i32;
        win.set_position(PhysicalPosition::new(
            m.position().x + (m.size().width as i32 - w) / 2,
            m.position().y,
        ))?;
    }
    system::tune_window(&win);
    win.set_ignore_cursor_events(true)?;
    win.show()?;

    let app2 = app.clone();
    let win2 = win.clone();
    std::thread::spawn(move || hover_loop(app2, win2));
    Ok(())
}

/// Окно прозрачное и больше острова, поэтому клики пропускаем сквозь него,
/// пока курсор не над самим островом. Заодно сообщаем интерфейсу о наведении.
fn hover_loop(app: AppHandle, win: WebviewWindow) {
    let mut last = false;
    loop {
        std::thread::sleep(Duration::from_millis(33));
        let Some((cx, cy)) = system::cursor() else { continue };
        let (w, h) = *app.state::<Shared>().rect.lock().unwrap();
        let (Ok(pos), Ok(size)) = (win.outer_position(), win.outer_size()) else { continue };
        let s = win.scale_factor().unwrap_or(1.0);
        let (iw, ih, pad) = (w * s, h * s, 6.0 * s);
        let left = pos.x as f64 + (size.width as f64 - iw) / 2.0;
        let top = pos.y as f64; // остров на 10px ниже верха окна; верхний край экрана тоже считается
        let (fx, fy) = (cx as f64, cy as f64);
        let inside = w > 0.0
            && fx >= left - pad
            && fx <= left + iw + pad
            && fy >= top
            && fy <= top + 10.0 * s + ih + pad;
        if inside != last {
            last = inside;
            let _ = win.set_ignore_cursor_events(!inside);
            let _ = app.emit("hover", inside);
        }
    }
}

fn setup_tray(app: &AppHandle) -> tauri::Result<()> {
    let settings = MenuItem::with_id(app, "settings", "Настройки", true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", "Выход", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&settings, &quit])?;
    let mut tray = TrayIconBuilder::new()
        .tooltip("Island")
        .menu(&menu)
        .on_menu_event(|app, ev| match ev.id.as_ref() {
            "quit" => app.exit(0),
            "settings" => {
                let app = app.clone();
                std::thread::spawn(move || open_settings(&app));
            }
            _ => {}
        });
    if let Some(icon) = app.default_window_icon() {
        tray = tray.icon(icon.clone());
    }
    tray.build(app)?;
    Ok(())
}

fn open_settings(app: &AppHandle) {
    if let Some(w) = app.get_webview_window("settings") {
        let _ = w.show();
        let _ = w.set_focus();
        return;
    }
    let _ = WebviewWindowBuilder::new(app, "settings", WebviewUrl::App("settings.html".into()))
        .title("Island — настройки")
        .inner_size(480.0, 680.0)
        .build();
}
